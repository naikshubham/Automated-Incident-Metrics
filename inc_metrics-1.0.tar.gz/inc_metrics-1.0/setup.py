from setuptools import setup

setup(name='inc_metrics',version='1.0',
		description="Sends an Automated mail for Incident Metrics",
		author = "Shubham & Nikhil",
		author_email='naikshubham55@gmail.com',
		py_modules=['INC_METRICS']
	)